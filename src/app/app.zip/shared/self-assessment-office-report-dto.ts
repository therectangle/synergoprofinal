export class SelfAssessmentOfficeDTO {
    $key: string = "";
    id: string = "";
    emailId:string="";
    question9ToDisplay: boolean;
  question10ToDisplay: boolean;
  question11ToDisplay: boolean;
  question12ToDisplay: boolean;

  mobiledevicesOptionsDivSectionToDisplay: boolean = false;
  paperdocumentsandpenOptionsDivSectionToDisplay: boolean = false;
  cafeOptionsDivSectionToDisplay: boolean = false;
  meetingroomOptionsDivSectionToDisplay: boolean = false;
  breakoutareaOptionsDivSectionToDisplay: boolean = false;
  questionNo1ForAOptionsDivSectionToDisplay: boolean = false;
  questionNo1ForBOptionsDivSectionToDisplay: boolean = false;
  questionNo1ForCOptionsDivSectionToDisplay: boolean = false;
  questionNo1ForDOptionsDivSectionToDisplay: boolean = false;
  questionNo1ForEOptionsDivSectionToDisplay: boolean = false;
  questionNo1ForFOptionsDivSectionToDisplay: boolean = false;
  questionNo1ForGOptionsDivSectionToDisplay: boolean = false;
  questionNo1ForHOptionsDivSectionToDisplay: boolean = false;
  questionNo1ForIOptionsDivSectionToDisplay: boolean = false;
  questionNo1ForJOptionsDivSectionToDisplay: boolean = false;
  questionNo1ForKOptionsDivSectionToDisplay: boolean = false;
  questionNo1ForLOptionsDivSectionToDisplay: boolean = false;
  questionNo1ForMOptionsDivSectionToDisplay: boolean = false;
  questionNo1ForNOptionsDivSectionToDisplay: boolean = false;


  questionNo2ForAOptionsDivSectionToDisplay: boolean = false;
  questionNo2ForBOptionsDivSectionToDisplay: boolean = false;
  questionNo2ForCOptionsDivSectionToDisplay: boolean = false;
  questionNo2ForDOptionsDivSectionToDisplay: boolean = false;
  questionNo2ForEOptionsDivSectionToDisplay: boolean = false;
  questionNo2ForFOptionsDivSectionToDisplay: boolean = false;

  questionNo3ForAOptionsDivSectionToDisplay: boolean = false;
  questionNo3ForBOptionsDivSectionToDisplay: boolean = false;
  questionNo3ForA_And_BSeleceted_DOptionsDivSectionToDisplay: boolean = false;
  questionNo3ForA_And_BSeleceted_EOptionsDivSectionToDisplay: boolean = false;
  questionNo3ForA_And_BSeleceted_FOptionsDivSectionToDisplay: boolean = false;
  questionNo3ForCOptionsDivSectionToDisplay: boolean = false;
  questionNo3ForDOptionsDivSectionToDisplay: boolean = false;
  questionNo3ForEOptionsDivSectionToDisplay: boolean = false;
  questionNo3ForFOptionsDivSectionToDisplay: boolean = false;
  questionNo3ForGOptionsDivSectionToDisplay: boolean = false;

  questionNo4ForAOptionsDivSectionToDisplay: boolean = false;
  questionNo4ForBOptionsDivSectionToDisplay: boolean = false;
  questionNo4ForCOptionsDivSectionToDisplay: boolean = false;

  questionNo5ForAOptionsDivSectionToDisplay: boolean = false;
  questionNo5ForBOptionsDivSectionToDisplay: boolean = false;
  questionNo5ForCOptionsDivSectionToDisplay: boolean = false;
  
  questionNo5ForA_ASeleceted_DOptionsDivSectionToDisplay: boolean = false;
  questionNo5ForB_ASeleceted_DOptionsDivSectionToDisplay: boolean = false;

  questionNo5ForA_BSeleceted_DOptionsDivSectionToDisplay: boolean = false;
  questionNo5ForB_BSeleceted_DOptionsDivSectionToDisplay: boolean = false;

  questionNo5ForA_CSeleceted_DOptionsDivSectionToDisplay: boolean = false;
  questionNo5ForB_CSeleceted_DOptionsDivSectionToDisplay: boolean = false;



  questionNo6ForAOptionsDivSectionToDisplay: boolean = false;
  questionNo6ForBOptionsDivSectionToDisplay: boolean = false;
  questionNo6ForCOptionsDivSectionToDisplay: boolean = false;
  questionNo6ForDOptionsDivSectionToDisplay: boolean = false;
  questionNo6ForEOptionsDivSectionToDisplay: boolean = false;
  questionNo6ForFOptionsDivSectionToDisplay: boolean = false;


  questionNo6ForABCOptionsDivSectionToDisplay: boolean = false;

  questionNo7ForAOptionsDivSectionToDisplay: boolean = false;
  questionNo7ForBOptionsDivSectionToDisplay: boolean = false;
  questionNo7ForCOptionsDivSectionToDisplay: boolean = false;
  questionNo8ForAOptionsDivSectionToDisplay: boolean = false;
  questionNo8ForBOptionsDivSectionToDisplay: boolean = false;
  questionNo8ForCOptionsDivSectionToDisplay: boolean = false;
  questionNo9ForAOptionsDivSectionToDisplay: boolean = false;
  questionNo9ForBOptionsDivSectionToDisplay: boolean = false;
  questionNo9ForCOptionsDivSectionToDisplay: boolean = false;
  questionNo10ForAOptionsDivSectionToDisplay: boolean = false;
  questionNo10ForBOptionsDivSectionToDisplay: boolean = false;
  questionNo10ForCOptionsDivSectionToDisplay: boolean = false;
  questionNo11ForAOptionsDivSectionToDisplay: boolean = false;
  questionNo11ForBOptionsDivSectionToDisplay: boolean = false;
  questionNo11ForCOptionsDivSectionToDisplay: boolean = false;
  questionNo12ForAOptionsDivSectionToDisplay: boolean = false;
  questionNo12ForBOptionsDivSectionToDisplay: boolean = false;
  questionNo12ForCOptionsDivSectionToDisplay: boolean = false;
  questionNo13ForAOptionsDivSectionToDisplay: boolean = false;
  questionNo13ForBOptionsDivSectionToDisplay: boolean = false;
  questionNo13ForCOptionsDivSectionToDisplay: boolean = false;
  questionNo13ForDOptionsDivSectionToDisplay: boolean = false;
  questionNo13ForEOptionsDivSectionToDisplay: boolean = false;
  questionNo14ForAOptionsDivSectionToDisplay: boolean = false;
  questionNo14ForBOptionsDivSectionToDisplay: boolean = false;
  questionNo14ForCOptionsDivSectionToDisplay: boolean = false;
  questionNo14ForDOptionsDivSectionToDisplay: boolean = false;
  questionNo15ForAOptionsDivSectionToDisplay: boolean = false;
  questionNo15ForBOptionsDivSectionToDisplay: boolean = false;
  questionNo15ForCOptionsDivSectionToDisplay: boolean = false;
  questionNo16ForAOptionsDivSectionToDisplay: boolean = false;
  questionNo16ForBOptionsDivSectionToDisplay: boolean = false;
  questionNo16ForAAOptionsDivSectionToDisplay: boolean = false;
  questionNo16ForABOptionsDivSectionToDisplay: boolean = false;
  questionNo16ForCOptionsDivSectionToDisplay: boolean = false;
  questionNo16ForDOptionsDivSectionToDisplay: boolean = false;
  questionNo16ForEOptionsDivSectionToDisplay: boolean = false;
  questionNo16ForFOptionsDivSectionToDisplay: boolean = false;
  isFinalError: boolean;
    
    
        
}
