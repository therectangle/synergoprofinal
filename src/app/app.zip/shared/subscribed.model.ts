export class Subscribed {
   
    email: string;
    sendDate:Date=new Date();
  }