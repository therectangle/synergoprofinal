export class Iinfo {
    name: string;
    email: string;
    pdfLink:string;
  }