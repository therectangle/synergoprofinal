export class Employee {
    id: string;
    fullName: string;
    empCode: string;
    position: string;
    mobile: string;
}
