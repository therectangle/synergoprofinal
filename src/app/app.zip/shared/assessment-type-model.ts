export class  AssessmentType
    {
        $key: string;
        code:string="";
        description:string="";
    }