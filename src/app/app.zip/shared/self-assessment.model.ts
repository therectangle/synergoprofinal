export class SelfAssessment {
    $key: string="";
    id: string="";
 emailId:string="";
    laptop1:string="";
    computer1:string="";
    mobile1:string="";

    laptop1Group:string="";
    computer1Group:string="";
    mobile1Group:string="";

    paperWork1:string="";
    computerWork1:string="";
    callsVirtualMeetings1:string="";

    paperWork1Group:string="";
    computerWork1Group:string="";
    callsVirtualMeetings1Group:string="";

    perchedForward:string="";
    leaningForward:string="";
    slouching:string="";
    sittingBack:string="";
    offTheFloorRestingOnCasters:string="";
    question4Options:string="";
   
    question5Options:string="";
    
    question6Options:string="";
    question6Option1:string="";
    question6Option2:string="";
    question6Option3:string="";
    
    question7Options:string="";
    question7Option1:string="";
    question7Option2:string="";
    question7Option3:string="";

    question8Options:string="";
    question8Option1:string="";
    question8Option2:string="";

    sitting:string="";    
    standing:string="";
    stretching:string="";
    takingBreaks:string="";

    sittingGroup:string="";    
    standingGroup:string="";
    stretchingGroup:string="";
    takingBreaksGroup:string="";

    /*hazardDescriptionImages: Map<string,string>;
    hazardHazards: string="";
    itemHeader: Map<string,string>;
    option: string="";
    recommendationRenderingComponentsBonusTips: Map<string,string>;
    recommendationRenderingComponentsProductRecommendation: Map<string,string>;
    recommendationRenderingComponentsRecommendationProduct_DIY: Map<string,string>;
    recommendationRenderingComponentsTitle: Map<string,string>;
    selection_type: string="";
    severity_rating: string="";
    type: string="";
    sequence:number*/


}
