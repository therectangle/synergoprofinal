import { AssessmentType } from './assessment-type-model';

export class ReasonForAssessment
{
    $key: string;
    code:string="";
    description:string="";
    



}